from django.shortcuts import render, get_object_or_404
from .models import Posts
 
def allposts(request):
    post = Posts.objects
    return render(request, 'blog/posts.html', {'post':post})
 
def detail(request, blog_id):
    postdetail = get_object_or_404(Posts, pk=blog_id)
    return render(request, 'blog/details.html', {'post':postdetail})
